public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        byte myByte = 2; // From -129 to 127//
        int myID = 1805; // whole number//
        float myFloatID = 12.385F; // floating point number//
        char myName1 = 'Y'; //First Characteristic Symbol//
        char myName2 = 'U';
        short myShortID = 005;
        boolean myBool = true;
        System.out.println(myName1);
        System.out.println(myName1+myName2);
        System.out.println(myFloatID);
        System.out.println(myName2);
        System.out.println(myID);

        char symbol1 = 'G';
        int digit2 = 89;
        byte simple = 4;
        short value = 56;
        float myCount = 4.7333436f;
        double myDouble = 4.355453532;
        long myLong =12123L;
        System.out.println(symbol1);
        System.out.println(digit2);
        System.out.println(simple);
        System.out.println(value);
        System.out.println(myCount);
        System.out.println(myDouble);
        System.out.println(myLong);

        long digitFull = 365L;
        System.out.println(digitFull);
        byte digit01 = 3;
        byte digit02 = 6;
        int digit03 = 5;
        System.out.println(digit01);
        System.out.println(digit02);
        System.out.println(digit03);

        int numOne = 168;
        int numTwo = 150;
        System.out.println(numOne);
        System.out.println(numTwo);
        System.out.println(numOne+numTwo);
        System.out.println(numOne-numTwo);
        System.out.println(numOne*numTwo);
        System.out.println(numOne/numTwo);
        System.out.println(numOne%numTwo);
        System.out.println(numOne/numTwo+numOne%numTwo);
    }
}