public class HomeTask2 {
    public static void main(String[] args) {
        // Исследование с переменными //
        // Задание 1 - переход марсимального(минимального) значения переменной
        byte a = 127;
        System.out.println("Макс знач Byte =" + a);
        short b = -32768;
        System.out.println("Min знач Short = " + b);
        int c = -2147483648;
        System.out.println("Min знач Int = " + c);
        long d = 9223372036854775807L;
        System.out.println("Макс знач Long =" + d);

    }

}
