public class ExtraTask2 {
    ///Testing multiply Classes in One Project //
    public static void main(String[] args) {
        long digitFull = 629l;
        long a = digitFull / 100;
        long b = (digitFull / 10) % 10;
        long c = digitFull % 10;
        System.out.println("Full Digit = " + digitFull + " литров;");
        System.out.println("Number 1 = " + a + ";");
        System.out.println("Number 2 =" + b);
        System.out.println("number 3 =" + c);
    }
}