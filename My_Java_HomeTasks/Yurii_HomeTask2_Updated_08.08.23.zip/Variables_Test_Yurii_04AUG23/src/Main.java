public class Main {
    public static void main(String[] args) {
        byte myByte = 2; // From -129 to 127//
        int myID = 1805; // whole number//
        float myFloatID = 12.385F; // floating point number//
        char myName1 = 'Y'; //First Characteristic Symbol//
        char myName2 = 'U'; //Second Characteristic Symbol//
        char myName3 = 'R'; //Third Characteristic Symbol//
        char myName4 = 'I'; //Fourth Characteristic Symbol//
        char myName5 = 'I'; //Fifth Characteristic Symbol//
        short myShortID = 005;
        boolean myBool = true;
        System.out.println("Мой номер = " + myID + ";");
        System.out.println("Мое Имя = " + myName1 + myName2 + myName3 + myName4 + myName5 + ";");
        System.out.println("Мое число = " + myFloatID + ";");
        System.out.println("Мое цифра = " + myShortID + ";");
        System.out.println("Мой результат = " + myBool + ";");

        char symbol1 = 'G';
        int digit2 = 89;
        byte simple = 4;
        short value = 56;
        float myCount = 4.7333436f;
        double myDouble = 4.355453532;
        long myLong = 12123L;
        System.out.println(symbol1);
        System.out.println(digit2);
        System.out.println(simple);
        System.out.println(value);
        System.out.println(myCount);
        System.out.println(myDouble);
        System.out.println(myLong);

        int number01 = 300;
        int number02 = 40;
        int number03 = 5;
        int fullDigit = (number01 + number02 + number03);
        System.out.println("Целое число = " + fullDigit);

        int numOne = 168;
        int numTwo = 150;
        System.out.println(numOne);
        System.out.println(numTwo);
        System.out.println(numOne + numTwo);
        System.out.println(numOne - numTwo);
        System.out.println(numOne * numTwo);
        System.out.println(numOne / numTwo);
        System.out.println(numOne % numTwo);
        System.out.println(numOne / numTwo + numOne % numTwo);
    }
}