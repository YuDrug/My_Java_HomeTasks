import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {
        System.out.println("Урок №3 Домашнее задание !");
//        Задание 1
//1 Напишите программу, в которой объявите переменные всех примитивных типов.
// Значение для каждой переменной сгенерируйте с помощью класса Random.
// При необходимости используйте приведение типов.
// Полученные значения выведите в консоль.
 Random random = new Random();
    long longValue = random.nextLong(10000000);
    System.out.println("Значение Long = " + longValue + ";");
    int intValue = random.nextInt(1500);
        System.out.println("Значение Inter = " + intValue + ";");
        float floatValue = (intValue/10)+random.nextFloat();
        System.out.println("Значение Float = " + floatValue + ";");
        double doubleValue = random.nextDouble();
        System.out.println("Значение Double = " + doubleValue + ";");
        double tempValue = random.nextDouble(20.5, 65.2);
        System.out.println("Значение Temperature = " + tempValue + "град;");
        boolean boleenValue = random.nextBoolean();
        System.out.println("Значение Boolean = " + boleenValue + ";");
        String stringValue = UUID.randomUUID().toString();
        System.out.println("Произвольная строка символов = " + stringValue);
        String stringLine = String.valueOf(stringValue);
        System.out.println("Произвольный знак = " + stringLine);
//
//        Задание 2
//Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
// Когда все данные введены, программа должна выдать сообщение: «Уважаемый, [Имя]!
// В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.».
// В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.

            System.out.println("Задание №2 - ввод данных Scanner data и Random ");
        Scanner scr = new Scanner(System.in);
        System.out.print("Введите ваше имя: ");
        String name = scr.nextLine();
        System.out.print("Введите ваш возраст: " + " полных лет.");
        int age = scr.nextInt();
        System.out.println("Уважаемый " + name + " в свои " + age + " Вы для нас дороги как золото!");
//Задание 3
//Напишите программу, которая получает от пользователя два целых числа и затем вычисляет сумму
// (сложение), разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел.
// Результат вычислений выведите в консоль.
        
    }
}