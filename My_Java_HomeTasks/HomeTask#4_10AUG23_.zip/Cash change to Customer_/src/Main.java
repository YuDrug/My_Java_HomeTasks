import java.util.Scanner;

import static java.lang.Float.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Task#2 - My Money Change Calculator.");
        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
        // которую дал покупатель. Выведите сумму сдачи в виде “X рублей и Y копеек”.
        Scanner scn1 = new Scanner(System.in);
        System.out.println("Введите стоимость товара в EUR.Cents = ");
        Float priceEurCent = Float.valueOf(scn1.nextLine());
        System.out.println("Введите деньги клиента в EUR.Cents= ");
        Float custMoney = Float.valueOf(scn1.nextLine());
        float restCash = (custMoney - priceEurCent);
        int restEur = (int)restCash;
        int restCents = (int)restCash - restEur;
        System.out.println("Ваша сдача = " + restEur + " Eur;" + restCents + " Cents");


        //1 Дана длина в метрах.
// Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
// Выведите начальное и конвертированные значения на экран.

        System.out.println("Task#1 - My Unit Convertor .");
        Scanner lengthValue = new Scanner(System.in);
        System.out.println("Введите значение длины в метрах: ");
        float meterLength = Float.parseFloat(lengthValue.nextLine());
        float kiloConst = 1000.000f;
        float feetConst = 3.2808f;
        float mileConst = 0.0006213711922f;
        float resInKilo = (meterLength / kiloConst);
        float resInFeet = (meterLength * feetConst);
        float resInMiles = (meterLength * mileConst);
        System.out.println("Километр = " + resInKilo + " км;");
        System.out.println("Футі = " + resInFeet + " фт;");
        System.out.println("Мілі = " + resInMiles + " мл;");


// 4. Пользователь вводит целое число.
// Напишите программу, которая делит это число на 2 и выводит результат.
// Остаток деления можно отбросить. Операторы деления / и остатка от деления % применять нельзя.

        System.out.println("Task#4 - Number Division on 2.");
    Scanner scn = new Scanner(System.in);
    System.out.println("Введите любое целое число: ");
    int entryNumber = scn.nextInt();
    int halfNumb = entryNumber >> 1;
        System.out.println("Результат деления пополам = " + halfNumb);

// 3 Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather), то ребята пойдут в поход.
// Если туркружок закупит дождевики (hasBoughtRaincoats) к концу учебного года, то ребята пойдут в поход даже в плохую погоду.
// В поход ребят должен кто-то повести. Поведёт тренер Джим, если он освободится от сдачи тренерского экзамена (isJimFree),
// или тренер Кейт, если она вернётся из путешествия (hasKateComeBack). Вести детей может только один тренер.
// Если Джим и Кейт смогут вести детей вместе, то они обязательно поссорятся из-за этого и никто никуда не пойдёт.

        System.out.println("Task#3 - Пойдут ли дети в Поход Летом ?.");
        boolean isYearFinished = false;
        boolean isWeatherGood = true;
        boolean hasBoughtRaincoats = true;
        boolean isJimWillFree = true;
        boolean hasKateComeBack = false;

        boolean goToCamp = isYearFinished && (isWeatherGood || hasBoughtRaincoats) && (isJimWillFree ^ hasKateComeBack);
        System.out.println("Пойдут в поход = " + goToCamp);

    }
}