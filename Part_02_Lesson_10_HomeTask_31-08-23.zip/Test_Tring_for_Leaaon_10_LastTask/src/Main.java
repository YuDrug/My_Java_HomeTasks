
public class Main {
    public static void main(String[] args) {
        System.out.println("ДомЗадание №3_Урок №10 - 31авг2023");

// Задание 3 - СТРИНГ и ЕГО МЕТОДЫ

//    3.1. + Создайте строку через new - I study Basic Java!
        System.out.println("Создание строки из масива данных типа Srting.");
        String myStrings = new String("I study Basic Java!");

//    3.3. Распечатать последний символ строки. Используем метод String.charAt().
        System.out.println("Строка записана явно в переменной типа String: \n" + myStrings);
        System.out.println("Последний символ моей новой строки: " + myStrings.charAt(args.length+18));
        System.out.println("Первый символ моей новой строки: " + myStrings.charAt(args.length));


//    3.4. Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
        System.out.println("Проверка на содержание определенного слова в масcиве типа String ");
        if (myStrings.contains("Jaba")) {
            System.out.println("Ключевое слово Java присутствует в строке myStrings!");
        }
        else {
            System.out.println("Ключевое слово Java отсутствует в строке myStrings!");
        }
//    3.5. Заменить все символы “а” на “о”. replace()
        System.out.println("Замена символов в строке.");
        System.out.println(myStrings.replace('a', 'o'));
        System.out.println(myStrings.replaceAll("study" , "cannot study"));
        System.out.println(myStrings.replaceFirst("I" , "They"));

        System.out.println("Преобразование строки в ВЕРХНИЙ регистр и нижний РЕГИСТР.");

//    3.6. Преобразуйте строку к верхнему регистру. toUpperCase(local.root)
        System.out.println(myStrings.toUpperCase());
//    3.7. Преобразуйте строку к нижнему регистру.  toLowerCase(local.root)
        System.out.println(myStrings.toLowerCase());

        System.out.println("Вырезание слова Java из масива типа String с помощью метода substring() ");

//    3.8. Вырезать строку Java c помощью метода String.substring(index.of). String.substring(0, StringName.lastIndex("Java"))

        System.out.println(myStrings.substring(myStrings.lastIndexOf("Java")));

    }

}