import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("HomeTask MultiRowsArrays & Strings_31AUG23");
//    Двумерные массивы
//    1. Создайте двумерный массив и заполните его заглавными буквами русского алфавита.
//    Буква Ё должна быть на своём месте.
        System.out.println("2-x Array - russish ALPHABET!");
        System.out.println("____________________________________________________________");
        char[][] alphabet = {
                {'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П'},
                {'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я'}
        };
        System.out.println(Arrays.deepToString(alphabet));
        System.out.println("_____________________________________________________________");

        char[][] alfabet = new char[2][20];
        char letter = 'А';
        for (char i = 0; i < alfabet.length; i++) {
            for (char j = 0; j < alfabet[i].length; j++) {
                alfabet[i][j] = letter;
                letter++;
                if (letter == 'Ж') {
                    j++;
                    alfabet[i][j] = 'Ё';
                }
                if (letter == 'Я' + 1) {
                    break;
                }
            }

        }
        System.out.println("____________________________________________________________________");
        System.out.println("Automated build russish Alphabed:");
        System.out.println(Arrays.deepToString(alfabet));


//    Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв (проверьте количество букв в слове).
//    Нужно получить слово, состоящее из первой половины первого слова и второй половины второго слова.
//    распечатать на консоль.


        Scanner scn = new Scanner(System.in);
        System.out.println("Entry 1st simple word:  ");
        String abc = scn.nextLine();
        if (abc.length() % 2 != 0) {
            System.out.println("Please entry another word с четными буквами: ");
            abc = scn.nextLine();
        }
        System.out.println("Введите 2е слово:  ");
        String cba = scn.nextLine();
        while (cba.length() % 2 != 0) {
            System.out.println("Введите иное слово с четными буквами: ");
            cba = scn.nextLine();
        }
        System.out.println("Новое Слово - ");
        System.out.println(abc.substring(0, abc.length() / 2) + (cba.substring(cba.length() / 2)));
    }

/
//    Вырезать строку Java c помощью метода String.substring(index.of). String.substring(0, StringName.lastIndex("Java"))


}
