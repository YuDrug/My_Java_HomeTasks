import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class ArrayHW {
    public static void main(String[] args) {
        System.out.println("Задание №2 Урок 24авг23 - Массивы и Методы");
//  1. Создайте массив из 8 случайных целых чисел из интервала [1;50]
//  2. Выведите массив на консоль в строку.
//  3. Замените каждый элемент с нечетным индексом на ноль.
//  4. Снова выведете массив на консоль в отдельной строке.
//  5. Отсортируйте массив по возрастанию.
//  6. Снова выведете массив на консоль в отдельной строке.

        Random rnd = new Random();
        int[] myArray = new int[8];
        for (int j = 0; j <= myArray.length; j++) { // TODO условие j <= myArray.length неправильное, потому что при j == myArray.length мы обратимся к элементу myArray[8], а у массива из 8 элементов последний имеет индекс 7
            myArray[j] = rnd.nextInt(1, 50); // TODO верхняя граница в nextInt исключена, поэтому надо указать 51
        }
        String asString = Arrays.toString(myArray);
        System.out.println("\n Мой линейный массив с индексом 8 " + asString);
        for (int j = 0; j <= myArray.length; j++) {
            // if (j % 2 = 0 && J!=0;) {} // TODO Двойное равно для равенства; условие про нечётные индексы, а не про чётные; большая J непонятно откуда взялась; лишняя точка с запятой
            // TODO можно убрать if вообще, а вместо него организовать сам цикл от j=1 c с шагом j+=2. Тогда в теле цикла будет одна строка myArray[j] = 0;

        }
        Arrays.sort(myArray);
        for (int num : myArray) { // TODO здесь либо используйте Arrays.toString, как в коде выше, либо цикл для вывода элементов. У Вас и то, и другое
            String mass1 = Arrays.toString(myArray);
            System.out.println("\n Сортированный линейный Массив Индекс 8 :  " + mass1);
            return;
        }
    }

}
