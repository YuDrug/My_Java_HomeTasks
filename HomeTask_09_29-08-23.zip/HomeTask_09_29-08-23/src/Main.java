import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;

public class Main {

    public static void main(String[] args) {
        System.out.println("Arrays - HomeTask Lesson_09 Date: 29AUG23");
        System.out.println("------------------------------------------------------------------------------------");
//        Задание:
//        1 Создайте массив из 8 элементов. В массиве должны храниться даты (класс LocalDate).
//        Чтобы создать элемент LocalDate используйте метод LocalDate.of(год, месяц, день), где год, месяц и день – целые числа.
//        Выведите массив в консоль.

        LocalDate[] myDate = {java.time.LocalDate.of(2023, 9, 3), java.time.LocalDate.of(2020, 10, 4), java.time.LocalDate.of(2021, 11, 5), java.time.LocalDate.of(2022, 12, 6), java.time.LocalDate.of(2017, 1, 7), java.time.LocalDate.of(2018, 2, 8), java.time.LocalDate.of(2019, 3, 9), java.time.LocalDate.of(2016, 4, 9),};
        System.out.println("------------------------------------------------------------------------------------");
        System.out.println("Original Dates Array");
        System.out.println(Arrays.toString(myDate));
        bubbleSortYear(myDate);
        System.out.println("------------------------------------------------------------------------------------");
        System.out.println("Sorted Dates Array by Year");
        System.out.println(Arrays.toString(myDate));
        System.out.println("------------------------------------------------------------------------------------");
        System.out.println("Sorted Dates Array by Day");
        bubbleSortDay(myDate);
        System.out.println(Arrays.toString(myDate));
        System.out.println("------------------------------------------------------------------------------------");

//        3 Напишите метод, который отсортирует массив дат по дню месяца.
//        Выведите массив в консоль.
    }
    //        2 Напишите метод, который отсортирует массив дат по году.
//     Выведите массив в консоль.
    private static void bubbleSortYear(LocalDate[] arr) {
        boolean swapped;
        do {
            swapped = false;
            for (int j = 0; j < arr.length - 1; j++) {
                if (arr[j].getYear() > arr[j + 1].getYear()) {
                    // Swap arr[j] and arr[j+1]
                    LocalDate temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
        } while (swapped);

    }
    private static void bubbleSortDay(LocalDate[] arr) {
        boolean swapped;
        do {
            swapped = false;
            for (int j = 0; j < arr.length - 1; j++) {
                if (arr[j].getDayOfMonth() > arr[j + 1].getDayOfMonth()) {
                    // Swap arr[j] and arr[j+1]
                    LocalDate temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    }
}