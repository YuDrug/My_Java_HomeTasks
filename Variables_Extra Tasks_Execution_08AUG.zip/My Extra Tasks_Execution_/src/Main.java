import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {

        // Исследование с переменными //
        System.out.println("Задание 1 - переход максимального(минимального) значения переменной");
        byte a = -128;
        short b = -32768;
        System.out.println("Предел памяти varByte = число " + a + ";" );
        System.out.println("Res1 = " + b / a + "деление;");
        System.out.println("Предел памяти varShort = число" + b + ";");
        int c = -2147483648;
        System.out.println("Min знач Int = " + c + ";");
        long d = 9223372036854775807L;
        System.out.println("Макс знач Long =" + d+ ";");

        System.out.println("Задание 2 - Операции с переменная целого и дробного типа");
        int e = 43;
        float f = 9.8f;
        System.out.println("Результат Деление int/float = " + e / f + ";");
        System.out.println("Результат умножения Int - Float = " + e * f + ";");
        System.out.println("Результат вычетиания Int - Float = " + (e - f) + ";");

        // при операциях с целым и дробным числами результат будет Float

        System.out.println("Задание 3 - Операции с переменными типа @Char");
        char q = 'X'-3;
        System.out.println("Symbol типа char = " + q + ";");
    }
}