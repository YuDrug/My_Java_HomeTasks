import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Methods {
    public static void main(String[] args) {

        // Задание 1.
        //Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х
        //чисел. В методе умножения 3-х чисел используйте вызов метода для
        //2-х чисел. В методе умножения 4-х чисел – вызов метода для 3-х
        //чисел.

        int m1 = multi1(5, 7);
        double m2 = multi1(-1,97);
        double m3 = multi1(2, -5, 3.5);
        System.out.println(m3);

        String str1 = concat("Hello ", "Yurii! ");
        //System.out.println(str1);
        String str2 = concat("How ", "are ", "You? ");
        //System.out.println(str2);
        String str3 = concat("What ", "do ", "You ", "Think? " );
        System.out.println("Результат умножения int a * b  равен = " + m1);
        System.out.println("Результат умножения double a * b  равен = " + m2);
        System.out.println("Результат умножения double a * b * c  равен = " + m3);
        System.out.println("__________________________________________________");
        System.out.println(" Конкатинация строк String перегруженными методами");
        System.out.println("String1 + String2: = " + str1);
        System.out.println("String1 + String2 + String3: = " + str2);
        System.out.println("String1 + String2 + String3 + String4: " + str3);

    }

    //TODO прежде, чем написать метод, нужно придумать, что он будет делать, какой результат возвращать и что получать на вход. Ниже я написал Javadoc, который должен помочь

    private static int multi1(int a, int b) {
        return a * b;
    }
    private static float multi1(int a, int b, int c) {
        return multi1(a, b) * c;
    }

    private static double multi1(int a, double b, double c) {
        return multi1(a, (int) b) * c;
    }

    private static String concat(String str1, String str2) {
        System.out.println("Two parameters Method ");
        return str1 + str2;
    }

    private static String concat(String s1, String s2, String s3) {
        System.out.println("Three parameters Method ");
        return concat(s1, s2) + s3;
    }

    private static String concat(String str1, String str2, String str3, String str4) {
        System.out.println("Four parameters Method ");
        return concat(str1, str2, str3) + str4;
    }

}
